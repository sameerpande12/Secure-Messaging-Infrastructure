javac Server.java
javac EncryptedServer.java
javac EncryptedSignatureServer.java
javac Client.java
javac EncryptedClient.java
javac EncryptedSignatureClient.java
javac FinalServer.java
javac FinalClient.java